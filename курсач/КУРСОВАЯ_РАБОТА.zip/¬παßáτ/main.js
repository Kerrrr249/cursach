// Маска российского номера телефона и простое подтверждение формы.
const phoneInput = document.getElementById('f-phone');
const bookingForm = document.getElementById('booking-form');
const bookingMessage = document.getElementById('booking-message');

function formatPhone(value) {
  let digits = value.replace(/\D/g, '');

  if (digits.startsWith('8')) {
    digits = '7' + digits.slice(1);
  }
  if (digits && !digits.startsWith('7')) {
    digits = '7' + digits;
  }

  digits = digits.slice(0, 11);
  let result = '+7';
  if (digits.length > 1) result += ' (' + digits.slice(1, 4);
  if (digits.length >= 4) result += ') ' + digits.slice(4, 7);
  if (digits.length >= 7) result += '-' + digits.slice(7, 9);
  if (digits.length >= 9) result += '-' + digits.slice(9, 11);
  return result;
}

phoneInput.addEventListener('focus', () => {
  if (!phoneInput.value) phoneInput.value = '+7 (';
});

phoneInput.addEventListener('input', () => {
  phoneInput.value = formatPhone(phoneInput.value);
});

bookingForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const name = document.getElementById('f-name').value;
  bookingMessage.textContent = `Спасибо, ${name}! Заявка принята. Мы перезвоним вам.`;
  bookingForm.reset();
});
